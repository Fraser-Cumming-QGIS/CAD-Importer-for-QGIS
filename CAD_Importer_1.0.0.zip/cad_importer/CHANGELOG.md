# Changelog

## 1.0.0

- Initial public release of CAD Importer.
- Import DXF drawings directly and convert DWG drawings through a separately installed ODA File Converter.
- Use QGIS's standard CRS selector without imposing a default CRS.
- Automatically discover ODA File Converter in common Windows locations while retaining manual executable selection.
- Clean and repair imported geometry, remove duplicates and empty fields, and separate content by CAD layer and geometry type.
- Add only non-empty layers whose features contain populated attributes.
- Name added layers using the source CAD layer name and label CAD text where available.
- Register the importer in the Processing Toolbox, plugin menu, toolbar and QGIS keyboard shortcut manager.
- Resolve temporary Processing outputs through the active QGIS context.
- Store converted DWG output under QGIS's managed temporary folder and defer deletion until file handles are released, preventing Windows `WinError 32`.
- Include publication metadata, documentation, maintainer-supplied icon and the official ODA File Converter download link.
